//
//  ReadViewController.swift
//  SwiftSampleFileManager
//
//  Created by Nadeeshan Jayawardana on 9/3/17.
//  Copyright © 2017 Nadeeshan Jayawardana (NEngineering). All rights reserved.
//

import UIKit

class ReadViewController: UIViewController {

    @IBOutlet var plistArrayTextView : UITextView!
    @IBOutlet var plistDictionaryTextView : UITextView!
    @IBOutlet var plistBooleanTextField : UITextField!
    @IBOutlet var plistDataTextField : UITextField!
    @IBOutlet var plistDateTextField : UITextField!
    @IBOutlet var plistNumberTextField : UITextField!
    @IBOutlet var plistStringTextField : UITextField!
    
    func readPlistFileValue() {
        
        // Read Array value form .plist file
        plistArrayTextView.text = String(describing: EasyPlistEditor(plistName: "SampleService-Info").getArrayWithKey(key: "SampleArrayVariable"))
        
        // Read Dictionary value form .plist file
        plistDictionaryTextView.text = String(describing: EasyPlistEditor(plistName: "SampleService-Info").getDictionaryWithKey(key: "SampleDictonaryVariable"))
        
        // Read Boolean value form .plist file
        plistBooleanTextField.text = String(describing: EasyPlistEditor(plistName: "SampleService-Info").getBooleanWithKey(key: "SampleBooleanVariable"))
        
        // Read Data value form .plist file
        plistDataTextField.text = String(describing: EasyPlistEditor(plistName: "SampleService-Info").getDataWithKey(key: "SampleDataVariable"))
        
        // Read Date value form .plist file
        plistDateTextField.text = String(describing: EasyPlistEditor(plistName: "SampleService-Info").getDateWithKey(key: "SampleDateVariable"))
        
        // Read Number value form .plist file
        plistNumberTextField.text = String(describing: EasyPlistEditor(plistName: "SampleService-Info").getNumberWithKey(key: "SampleNumberVariable"))
        
        // Read String value form .plist file
        plistStringTextField.text = String(describing: EasyPlistEditor(plistName: "SampleService-Info").getStringWithKey(key: "SampleStringVariable"))
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        readPlistFileValue()
    }
    
    @IBAction func readButtonAction (_ sender: AnyObject) {
        readPlistFileValue()
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
