//
//  EditViewController.swift
//  SwiftSampleFileManager
//
//  Created by Nadeeshan Jayawardana on 9/3/17.
//  Copyright © 2017 Nadeeshan Jayawardana (NEngineering). All rights reserved.
//

import UIKit

class EditViewController: UIViewController {

    @IBOutlet var plistBooleanSegmentedControl : UISegmentedControl!
    @IBOutlet var plistDateTextField : UITextField!
    @IBOutlet var plistNumberTextField : UITextField!
    @IBOutlet var plistStringTextField : UITextField!
    
    // function to update .plist file
    func updatePlistFileFunction() {
        // NSArray Value
        let sampleValueArray = ["SampleValueChange_1", "SampleValueChange_2", "SampleValueChange_3"]
        let arrayStatues = EasyPlistEditor(plistName: "SampleService-Info").setArray(value: sampleValueArray as NSArray, key: "SampleArrayVariable")
        if arrayStatues {
            print("Array value successfully set to .plist file")
        }
        
        // NSDictonary Value
        let SampleValueDictionary = ["SampleKey_1" : "SampleValueChange_1", "SampleKey_2" : "SampleValueChange_2", "SampleKey_3" : "SampleValueChange_3"]
        let dictionaryStatues = EasyPlistEditor(plistName: "SampleService-Info").setDictionary(value: SampleValueDictionary as NSDictionary, key: "SampleDictonaryVariable")
        if dictionaryStatues {
            print("Dictonary value successfully set to .plist file")
        }
        
        // Boolean Value
        let booleanStatues = EasyPlistEditor(plistName: "SampleService-Info").setBoolean(value: plistBooleanSegmentedControl.selectedSegmentIndex > 0 ? false : true, key: "SampleBooleanVariable")
        if booleanStatues {
            print("Boolean value successfully set to .plist file")
        }
        
        // Data Value
        let SampleData = Data(bytes: [UInt32](repeating: 0, count: 2048).map { _ in arc4random() }, count: 2048)
        let dataStatues = EasyPlistEditor(plistName: "SampleService-Info").setData(value: SampleData as NSData, key: "SampleDataVariable")
        if dataStatues {
            print("Data value successfully set to .plist file")
        }
        
        // Date Value
        let dateStatues = EasyPlistEditor(plistName: "SampleService-Info").setDate(value: Date() as NSDate, key: "SampleDateVariable")
        if dateStatues {
            print("Date value successfully set to .plist file")
        }
        
        // NSNumber Value
        let numberStatues = EasyPlistEditor(plistName: "SampleService-Info").setNumber(value: NSNumber.init(value: Int32(plistNumberTextField.text!)!), key: "SampleNumberVariable")
        if numberStatues {
            print("Number value successfully set to .plist file")
        }
        
        // NSString Value
        let stringStatues = EasyPlistEditor(plistName: "SampleService-Info").setString(value: plistStringTextField.text! as NSString, key: "SampleStringVariable")
        if stringStatues {
            print("String value successfully set to .plist file")
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        plistDateTextField.text = String(describing: Date())
    }
    
    @IBAction func updateButtonAction (_ sender:AnyObject) {
        // Call Update Function
        updatePlistFileFunction()
        
        // Dismiss the current view controller
        self.dismiss(animated: true, completion: nil)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
